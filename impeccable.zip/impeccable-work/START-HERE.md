# Impeccable — portable install (no npm / no npx required)

Impeccable **v3.8.0** — fresh build pulled from `github.com/pbakaus/impeccable`
(`main` @ `c979ac3`, 2026-06-29). Design skill + 23 commands + 44 deterministic
detector rules for AI coding agents.

This folder is trimmed to **Claude Code + GitHub Copilot only** (the other 11
tool folders from the universal bundle were removed). Nothing here needs
`npm install`, `npx`, or network access. You copy a folder and reload your tool.
That's the whole install.

## What changed since your old copy

Your old `impeccable-style-universal` was the pre-v3 layout: ~21 separate skill
folders (`polish/`, `audit/`, `critique/`, …), each its own `SKILL.md`.

v3 consolidated everything into **one skill** (`skills/impeccable/`) with the 23
commands moved into `reference/*.md`, plus a bundled deterministic detector under
`scripts/`. You now invoke `/impeccable <command> <target>` instead of separate
skills. Delete the old folders — the structures aren't compatible.

## Install (pick your tool, copy one folder)

These are hidden dotfolders. In Finder press `Cmd+Shift+.` to see them.

| Tool | Copy this folder | Into |
|------|------------------|------|
| **Claude Code** | `.claude/` | your project root (or merge into `~/.claude/`) |
| **GitHub Copilot** | `.github/` | your project root |

### Claude Code (your primary)

```bash
# project-local
cp -R impeccable-work/.claude your-project/

# or global, for every project
cp -R impeccable-work/.claude/* ~/.claude/
```

`.claude/` contains three pieces — copy all three:
- `skills/impeccable/` — the skill (SKILL.md + `reference/` + `scripts/`)
- `agents/impeccable-manual-edit-applier.md` — subagent the `live` mode uses
- `settings.json` — provider hook manifest. **If you already have a
  `~/.claude/settings.json`, merge the `hooks` block instead of overwriting.**

Reload Claude Code, then run `/impeccable init` once in a project to write
`PRODUCT.md`/`DESIGN.md`, then `/impeccable polish <target>`, `audit`, `critique`, etc.

### GitHub Copilot

```bash
cp -R impeccable-work/.github your-project/
```

`.github/` contains `skills/impeccable/` (SKILL.md + `reference/` + `scripts/`)
and `hooks/impeccable.json`. Same offline detector scripts as the Claude build.

## The detector runs offline too

The deterministic anti-pattern detector is bundled inside the skill — plain Node,
no dependencies, no API key. Verified working on Node v22:

```bash
node .claude/skills/impeccable/scripts/detect.mjs path/to/file.html
node .claude/skills/impeccable/scripts/context.mjs        # reads PRODUCT.md/DESIGN.md
```

Node 18+ works; the project officially targets 24+, but the skill scripts ran
clean on 22. Optional code paths for Svelte/Babel parsing lazy-load those
packages only if present — core HTML/CSS/text detection needs nothing.

## What this bundle does NOT include

The standalone `npx impeccable` CLI (the CI detector + installer) is a separate
npm package with real dependencies (`css-tree`, `htmlparser2`, `puppeteer`, …).
You don't need it: the installer is replaced by copying these folders, and the
detector ships inside the skill. If you also want the standalone CLI vendored
with its `node_modules` for offline CI, ask and I'll bundle that separately.

The `npx impeccable update` check in the skill's `allowed-tools` is optional —
offline it simply no-ops; nothing breaks.
