Impeccable. Design fluency for AI harnesses.
https://impeccable.style

Trimmed to two tools:

  .claude/    -> Claude Code
  .github/    -> GitHub Copilot

To install, copy the relevant folder into your project root.
These are hidden folders (dotfiles). Press Cmd+Shift+. in Finder to see them.

See START-HERE.md for the no-install / offline details.
